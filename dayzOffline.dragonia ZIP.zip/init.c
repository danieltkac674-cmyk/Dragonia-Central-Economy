void main()
{
	//INIT ECONOMY--------------------------------------
	Hive ce = CreateHive();
	if ( ce )
		ce.InitOffline();

	//DATE RESET AFTER ECONOMY INIT-------------------------
	int year, month, day, hour, minute;
	int reset_month = 9, reset_day = 20;
	GetGame().GetWorld().GetDate(year, month, day, hour, minute);

	if ((month == reset_month) && (day < reset_day))
	{
		GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
	}
	else
	{
		if ((month == reset_month + 1) && (day > reset_day))
		{
			GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
		}
		else
		{
			if ((month < reset_month) || (month > reset_month + 1))
			{
				GetGame().GetWorld().SetDate(year, reset_month, reset_day, hour, minute);
			}
		}
	}
//	IntroSceneCharacter.SetSceneClass("CustomIntroScene");
//GetCEApi().ExportProxyData("4096 0 4096", 8192);	// standard map groups (buildings) export, terrain center and radius needs to be specified
//GetCEApi().ExportClusterData();						// cluster-type map groups export (fruit trees etc.)
}

class CustomMission: MissionServer
{
	void SetRandomHealth(EntityAI itemEnt)
	{
		if ( itemEnt )
		{
			float rndHlt = Math.RandomFloat( 0.45, 0.65 );
			itemEnt.SetHealth01( "", "", rndHlt );
		}
	}

	override PlayerBase CreateCharacter(PlayerIdentity identity, vector pos, ParamsReadContext ctx, string characterName)
	{
		Entity playerEnt;
		playerEnt = GetGame().CreatePlayer( identity, characterName, pos, 0, "NONE" );
		Class.CastTo( m_player, playerEnt );

		GetGame().SelectPlayer( identity, m_player );

		return m_player;
	}

	override void StartingEquipSetup(PlayerBase player, bool clothesChosen)
	{
		EntityAI itemClothing;
		EntityAI itemEnt;
		ItemBase itemBs;
		float rand;

		// Zoznam všetkých pozícií (výška navýšená o 0.5m)
ref array<vector> customSpawnPositions = {
	"7824.729004 77.186729 1825.748047",		  // j 1
	"7755.966309 29.132124 2359.079346",		  // j 2
	"7871.896973 66.024323 1569.201904",		  // j 3
	"7910.461914 43.015175 1247.100098",		  // j 4
	"7870.558105 35.380173 632.363647",		  // j 5
	"7621.750977 55.341003 416.814209",		  // j 6
	"7014.216797 81.696114 371.780548",		  // j 7
	"7004.443848 107.364487 466.303223",		  // j 8
	"6704.452148 43.448460 282.483276"		  // j 9
};

// Zoznam zodpovedajúcich orientácií v presne rovnakom poradí
ref array<vector> customSpawnOrientations = {
    "23.645721 0.000000 -0.000000",       // j 1
    "-9.224532 0.000000 -0.000000",       // j 2
    "112.900841 0.000000 -0.000000",       // j 3
    "170.960754 0.000000 -0.000000",       // j 4
    "16.561918 0.000000 -0.000000",       // j 5
    "-106.793518 0.000000 -0.000000",       // j 6
    "-106.793518 0.000000 -0.000000",       // j 7
    "-159.724579 0.000000 -0.000000",       // j 8
    "28.490650 0.000000 -0.000000"		  // j 9
};

// 1. Vygeneruje náhodný index od 0 po počet položiek
int randomIndex = Math.RandomInt(0, customSpawnPositions.Count());

// 2. Priradenie hodnôt z polí podľa náhodného indexu do premenných
vector customSpawnPos = customSpawnPositions[randomIndex];
vector customSpawnOri = customSpawnOrientations[randomIndex];

// 3. Fyzické umiestnenie a natočenie hráča
player.SetPosition(customSpawnPos);
player.SetOrientation(customSpawnOri);
	
		itemClothing = player.FindAttachmentBySlotName( "Body" );
		if ( itemClothing )
		{
			SetRandomHealth( itemClothing );
			
			itemEnt = itemClothing.GetInventory().CreateInInventory( "BandageDressing" );
			if ( Class.CastTo( itemBs, itemEnt ) )
				itemBs.SetQuantity( 2 );

			string chemlightArray[] = { "Roadflare", "Chemlight_Red", "Chemlight_White", "Chemlight_Red" };
			int rndIndex = Math.RandomInt( 0, 4 );
			itemEnt = itemClothing.GetInventory().CreateInInventory( chemlightArray[rndIndex] );
			SetRandomHealth( itemEnt );
			player.SetQuickBarEntityShortcut(itemEnt, 1);

			rand = Math.RandomFloatInclusive( 0.0, 1.0 );
			if ( rand < 0.35 )
				itemEnt = player.GetInventory().CreateInInventory( "Marmalade" );
			else if ( rand > 0.65 )
				itemEnt = player.GetInventory().CreateInInventory( "Pear" );
			else
				itemEnt = player.GetInventory().CreateInInventory( "Apple" );
			player.SetQuickBarEntityShortcut(itemEnt, 3);
			SetRandomHealth( itemEnt );

		}
		
		itemClothing = player.FindAttachmentBySlotName( "Legs" );
		if ( itemClothing )
		{
			SetRandomHealth( itemClothing );
			itemEnt = itemClothing.GetInventory().CreateInInventory( "Rag" );
			SetRandomHealth( itemEnt);
		}
		
		itemClothing = player.FindAttachmentBySlotName( "Feet" );
	}
};

Mission CreateCustomMission(string path)
{
	return new CustomMission();
}